<?php
    include "../part/head.php";
?>
<!--배경-->
<div class="bg">
    <div class="main-img-1"><img src="/resource/img/maltesers.png" alt=""></div>
    <div class="content">
        <div class="main-title-1 main-title">HOLLYS's</div>
        <div class="main-title-2 main-title">SEASON MENU</div>
        <div class="main-title-3 main-title">MALTESERS</div>
        <div class="main-title-4 main-title">#빙수를_FUN하게 #떤넹수 #몰티져스</div>
    </div>
    <div class="discover-box flex">
        <div class="discover-round-1">
            <div class="cross"></div>
        </div>
        <div class="discover-text flex-as-c">DISCOVER MORE</div>

    </div>
    <div class="bingsu-img"><img src="/resource/img/bingsu-1.png" alt=""></div>
</div>
<!--page 2-->
<div class="bg-2">
    <img class="wave" src="/resource/img/2page_wave.png" alt="">
    <div class="sub-title"><img src="/resource/img/alwaysBeWithYou.png" alt=""></div>
    <div class="line-2"></div>
    <div class="sub-title-2">할리스커피의 다양한 메뉴를 맛보세요</div>
    <div class="btn-go-to-menu"><a href="#">메뉴 보기</a></div>
    <div class="berry-box"><img class="berry" src="/resource/img/berry.png" alt="">
        <div class="berry-text">딸기치즈케익<br>할리치노</div>
    </div>
    <div class="vanilla-box"> <img class="vanilla" src="/resource/img/vanilla.png" alt="">
    <div class="vanilla-text">바닐라<br>딜라이트</div>
</div>
   
    <img class="choco" src="/resource/img/choco.png" alt="">

</div>

<?php
    include "../part/foot.php";
?>