<?php
    include "../part/head.php";
?>
    <!--배경-->
    <div class="bg">
        <div class="main-img-1"><img src="/resource/img/maltesers.png" alt=""></div>
        <div class="content">
            <div class="main-title-1 main-title">HOLLYS's</div>
            <div class="main-title-2 main-title">SEASON MENU</div>
            <div class="main-title-3 main-title">MALTESERS</div>
            <div class="main-title-4 main-title">#빙수를_FUN하게 #떤넹수 #몰티져스</div>
        </div>
        <div class="discover-box flex">
            <div class="discover-round-1">
                <div class="cross"></div>
            </div>
            <div class="discover-text flex-as-c">DISCOVER MORE</div>

        </div>
        <div class="bingsu-img"><img src="/resource/img/bingsu-1.png" alt=""></div>
    </div>
    <!--page 2-->
    <div class="bg-2">
        <img src="/resource/img/2page_wave.png" alt="">
        <div class="sub-title"><img src="/resource/img/alwaysBeWithYou.png" alt=""></div>
    </div>
<?php
    include "../part/foot.php";
?>
