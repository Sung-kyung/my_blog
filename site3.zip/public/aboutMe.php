<?php
    include "../part/head.php";
?>

<div class="bg-aboutMe con">
    <div class="intro-me"><img src="/resource/img-2/me1.jpg" alt=""></div>
    <div class="intro-me-text">About Me Title</div>
    <ul class="intro-me-content">
        <li>Name : Sung-kyung / Emma</li>
        <li>Age : 26</li>
        <li>Hobby : </li>
        <li>Nickname : Bible , 덕덕박사</li>
        <li>Birth : 1996. 01. 15</li>
        <li>Email : yoo960115@hanmail.net</li>
        <li>Skill : </li>
    </ul>
    <div class="line-c"></div>
    <div class="line-r"></div>

    <div class="avatar con flex">
        <img src="/resource/img/avatar.png" alt="" class="flex">
        
    </div>
    <div class="avatar-text flex">Level.26 / Bible / Student </div>

</div>


<?php
    include "../part/foot.php";
?>