<?php
    include "../part/head.php";
?>
    <h1 class="list-title con">< Cafe Tour List ></h1>
    
    
<ul class="detail-list-box con block ">
   
   
        <li class="detail-list"><div class="img-box"><img src="https://i.postimg.cc/pr3cZs3J/Kakao-Talk-20200623-023830701-1.jpg" alt=""></div>
        <a href="/detail.php?id=1">갈마동 Eventide</a>
    </li>
        
    <li class="detail-list-2">
    <div class="img-box"><img src="https://i.postimg.cc/Px6hykXs/image-10.png" alt=""></div>
    <a href="/detail.php?id=2">블로그 만들기</a></li>
</ul>

<?php
    include "../part/foot.php";
?>